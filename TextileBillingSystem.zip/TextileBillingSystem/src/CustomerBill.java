

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Project.ConnectionProvider;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import com.toedter.calendar.JDateChooser;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.Color;

@SuppressWarnings("serial")
public class CustomerBill extends JFrame {

	private JPanel contentPane;
	@SuppressWarnings("rawtypes")
	private JComboBox comboOrderID;
	private JTextField txtBillNo;
	private JTextField txtCustID;
	private JTextField txtCustName;
	private JTextField txtMatID;
	private JTextField txtQuantity;
	private JTextField txtRate;
	private JTextField txtAdvance;
	private JTextField txtBalance;
	private JTextField txtTotalEx;
	private JTextField txtMatName;
	private JTextField txtSize;

	/**
	 * Launch the application.
	 */
	public void clear()
	{ 
		txtBillNo.setText("");
		comboOrderID.removeItemAt(0);
		txtCustID.setText("");
		txtCustName.setText("");
		txtMatID.setText("");
		txtMatName.setText("");
		txtSize.setText("");
		txtQuantity.setText("");
		txtRate.setText("");
		txtAdvance.setText("");
		txtBalance.setText("");
		txtTotalEx.setText(""); 
	}
	private void autoID()
	{
		try
		{
			Connection con=ConnectionProvider.getcon();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select Max(BillNo) from customerbill ");
			rs.next();
			rs.getString("Max(BillNo)");
			if(rs.getString("Max(BillNo)")==null)
			{
				txtBillNo.setText("01");
			}
			else
			{
				Long id = Long.parseLong(rs.getString("Max(BillNo)").substring(0,rs.getString("Max(BillNo)").length()));
				id++;
				txtBillNo.setText("0" + String.format("%d",id));
			}
		}
			catch(Exception e)
			{
				JOptionPane.showMessageDialog(null, e);
			}
		
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CustomerBill frame = new CustomerBill();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public CustomerBill() {
		setTitle("Customer Bill");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 723, 514);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 165, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 24, 667, 122);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Customer Details :");
		lblNewLabel.setFont(new Font("Modern No. 20", Font.BOLD, 17));
		lblNewLabel.setBounds(10, 11, 162, 23);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Bill ID :");
		lblNewLabel_1.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(37, 45, 76, 23);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Customer ID :");
		lblNewLabel_1_1.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1_1.setBounds(10, 85, 85, 23);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Order ID :");
		lblNewLabel_1_1_1.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1_1_1.setBounds(339, 45, 85, 23);
		panel.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("Customer Name :");
		lblNewLabel_1_1_2.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1_1_2.setBounds(302, 85, 112, 23);
		panel.add(lblNewLabel_1_1_2);
		
		txtBillNo = new JTextField();
		txtBillNo.setBounds(106, 45, 117, 20);
		panel.add(txtBillNo);
		txtBillNo.setColumns(10);
		
		txtCustID = new JTextField();
		txtCustID.setColumns(10);
		txtCustID.setBounds(106, 86, 117, 20);
		panel.add(txtCustID);
		
		txtCustName = new JTextField();
		txtCustName.setColumns(10);
		txtCustName.setBounds(421, 86, 197, 20);
		panel.add(txtCustName);
		
		JComboBox combOrderID = new JComboBox();
		comboOrderID.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Oid =  comboOrderID.getSelectedItem().toString();
				try
				{
					Connection con= ConnectionProvider.getcon();
					java.sql.Statement st= con.createStatement();
					ResultSet rs = ((java.sql.Statement) st).executeQuery("select * from customerorder where OrderID='"+Oid+"'");
					if(rs.next())
					{
						txtCustID.setText(rs.getString(3));
						txtCustName.setText(rs.getString(4));
						txtMatID.setText(rs.getString(5));
						txtMatName.setText(rs.getString(6));
						txtSize.setText(rs.getString(7));
						txtQuantity.setText(rs.getString(8));
							
					}
					else 
					{
						JOptionPane.showMessageDialog(null, "Customer does not Exist");
						clear();
						
					}
					
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null, e1);
			
				}
			}
		});
		comboOrderID.setFont(new Font("Modern No. 20", Font.PLAIN, 16));
		combOrderID.setBounds(421, 45, 197, 22);
		comboOrderID.setEditable(true);
		panel.add(combOrderID);
		try
		{
			int i = 0;
			Connection con = ConnectionProvider.getcon();
			Statement st = con.createStatement();
			
			ResultSet rs=st.executeQuery("select * from customerorder ");
				
			
			while(rs.next())
			{		
				i = 1 ;
				comboOrderID.addItem(rs.getString("OrderID")); 
			}
			con.close();
			if(i==0)
			{
				 
				JOptionPane.showMessageDialog(null,"Customer Order ID Not Available");
				
			}
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null, e);
		}
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(10, 168, 329, 223);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblMaterialDetails = new JLabel("Material Details :");
		lblMaterialDetails.setFont(new Font("Modern No. 20", Font.BOLD, 16));
		lblMaterialDetails.setBounds(10, 11, 162, 23);
		panel_1.add(lblMaterialDetails);
		
		JLabel lblNewLabel_2 = new JLabel("Material ID :");
		lblNewLabel_2.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(36, 62, 92, 23);
		panel_1.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("Material Name :");
		lblNewLabel_2_1.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_2_1.setBounds(20, 96, 113, 23);
		panel_1.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_2 = new JLabel("Size :");
		lblNewLabel_2_2.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_2_2.setBounds(85, 130, 61, 23);
		panel_1.add(lblNewLabel_2_2);
		
		JLabel lblNewLabel_2_3 = new JLabel("Quantity (Box) :");
		lblNewLabel_2_3.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_2_3.setBounds(15, 164, 118, 23);
		panel_1.add(lblNewLabel_2_3);
		
		txtMatID = new JTextField();
		txtMatID.setColumns(10);
		txtMatID.setBounds(142, 63, 113, 20);
		panel_1.add(txtMatID);
		
		txtQuantity = new JTextField();
		txtQuantity.setColumns(10);
		txtQuantity.setBounds(142, 165, 113, 20);
		panel_1.add(txtQuantity);
		
		txtMatName = new JTextField();
		txtMatName.setBounds(143, 97, 112, 20);
		panel_1.add(txtMatName);
		txtMatName.setColumns(10);
		
		txtSize = new JTextField();
		txtSize.setBounds(142, 131, 113, 20);
		panel_1.add(txtSize);
		txtSize.setColumns(10);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(369, 168, 308, 223);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblTotal = new JLabel("Total :");
		lblTotal.setFont(new Font("Modern No. 20", Font.BOLD, 16));
		lblTotal.setBounds(10, 11, 162, 23);
		panel_2.add(lblTotal);
		
		JLabel lblNewLabel_2_4 = new JLabel("Rate :");
		lblNewLabel_2_4.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_2_4.setBounds(64, 45, 58, 23);
		panel_2.add(lblNewLabel_2_4);
		
		JLabel lblNewLabel_2_5 = new JLabel("Advance :");
		lblNewLabel_2_5.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_2_5.setBounds(45, 79, 77, 23);
		panel_2.add(lblNewLabel_2_5);
		
		JLabel lblNewLabel_2_6 = new JLabel("Balance :");
		lblNewLabel_2_6.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_2_6.setBounds(45, 113, 70, 23);
		panel_2.add(lblNewLabel_2_6);
		
		JLabel lblNewLabel_2_7 = new JLabel("Total Expenses :");
		lblNewLabel_2_7.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_2_7.setBounds(10, 147, 121, 23);
		panel_2.add(lblNewLabel_2_7);
		
		txtRate = new JTextField();
		txtRate.setColumns(10);
		txtRate.setBounds(118, 46, 127, 20);
		panel_2.add(txtRate);
		
		txtAdvance = new JTextField();
		txtAdvance.setColumns(10);
		txtAdvance.setBounds(118, 80, 127, 20);
		panel_2.add(txtAdvance);
		
		txtBalance = new JTextField();
		txtBalance.setColumns(10);
		txtBalance.setBounds(118, 113, 127, 20);
		panel_2.add(txtBalance);
		
		txtTotalEx = new JTextField();
		txtTotalEx.setColumns(10);
		txtTotalEx.setBounds(118, 148, 127, 20);
		panel_2.add(txtTotalEx);
		
		JButton btnCalculate = new JButton("Calculate ");
		btnCalculate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int advance= Integer.parseInt(txtAdvance.getText());
				int Rate= Integer.parseInt(txtRate.getText());
				int Quant= Integer.parseInt(txtQuantity.getText());  
				String Total= String.valueOf(Quant*Rate);
				txtTotalEx.setText(Total);
				int Total1= Integer.parseInt(txtTotalEx.getText());
				String balance= String.valueOf(Total1 - advance);
				txtBalance.setText(balance);
				
			}
		});
		btnCalculate.setFont(new Font("Modern No. 20", Font.PLAIN, 17));
		btnCalculate.setBounds(102, 189, 121, 23);
		panel_2.add(btnCalculate);
		
		JLabel lblNewLabel_2_4_1 = new JLabel("Date :");
		lblNewLabel_2_4_1.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_2_4_1.setBounds(64, 15, 58, 23);
		panel_2.add(lblNewLabel_2_4_1);
		
		JDateChooser txtdateChooser = new JDateChooser();
		txtdateChooser.setBounds(118, 14, 153, 20);
		panel_2.add(txtdateChooser);
		
	
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Cbill= txtBillNo.getText();
				String Oid =  comboOrderID.getSelectedItem().toString();
				String Cid= txtCustID.getText();
				String Cname= txtCustName.getText();
			    String Mid= txtMatID.getText();
			    String Mname= txtMatName.getText();
			    String size=txtSize.getText();
			    String Quant= txtQuantity.getText();
			    String Rate=txtRate.getText();
			    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				String date= sdf.format(txtdateChooser.getDate());
			    String advance= txtAdvance.getText();
			    String balance= txtBalance.getText();
			    String Total= txtTotalEx.getText();
			   
				try
				{
					Connection con=ConnectionProvider.getcon();	
					PreparedStatement ps = con.prepareStatement("insert into customerbill values(?,?,?,?,?,?,?,?,?,?,?,?,?)");
					ps.setString(1,Cbill);
					ps.setString(2,Oid);
					ps.setString(3,Cid);
					ps.setString(4,Cname);
					ps.setString(5,Mid);
					ps.setString(6,Mname);
					ps.setString(7,size);
					ps.setString(8,Quant);
					ps.setString(9,Rate);
					ps.setString(10,date);
					ps.setString(11,advance);
					ps.setString(12,balance);
					ps.setString(13,Total);
			 
					ps.executeUpdate();
					JOptionPane.showMessageDialog(null,"Customer Bill SuccessFully Added...");
				
					clear(); 
					autoID();
					
				}
				catch(Exception e1)
				{
			
				}
			}
		});
		
		btnSave.setFont(new Font("Modern No. 20", Font.PLAIN, 17));
		btnSave.setBounds(23, 419, 89, 23);
		contentPane.add(btnSave);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Cbill= txtBillNo.getText();
				String Oid =  comboOrderID.getSelectedItem().toString();
				String Cid= txtCustID.getText();
				String Cname= txtCustName.getText();
			    String Mid= txtMatID.getText();
			    String Mname= txtMatName.getText();
			    String size=txtSize.getText();
			    String Quant= txtQuantity.getText();
			    String Rate=txtRate.getText();
			    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				String date= sdf.format(txtdateChooser.getDate());
			    String advance= txtAdvance.getText();
			    String balance= txtBalance.getText();
			    String Total= txtTotalEx.getText();
			   
				try
				{
					Connection con=ConnectionProvider.getcon();	
					PreparedStatement ps = con.prepareStatement("update customerbill set BillNo=?,OrderID=?,CustID=?,CustName=?,MatID=?,MatName=?,Size=?,Quantity=?,Rate=?,Date=?,Advance=?,Balance=?,TotalEx=? where BillNo='"+Cbill+"'");
					ps.setString(1,Cbill);
					ps.setString(2,Oid);
					ps.setString(3,Cid);
					ps.setString(4,Cname);
					ps.setString(5,Mid);
					ps.setString(6,Mname);
					ps.setString(7,size);
					ps.setString(8,Quant);
					ps.setString(9,Rate);
					ps.setString(10,date);
					ps.setString(11,advance);
					ps.setString(12,balance);
					ps.setString(13,Total);
			 
					ps.executeUpdate();
					JOptionPane.showMessageDialog(null,"Customer Bill SuccessFully Updated...");
				
					clear(); 
					autoID();
					
				}
				catch(Exception e1)
				{
				
				}
			}
		});
		btnUpdate.setFont(new Font("Modern No. 20", Font.PLAIN, 17));
		btnUpdate.setBounds(137, 420, 89, 23);
		contentPane.add(btnUpdate);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Cbill=txtBillNo.getText();
				try
				{
					Connection con=ConnectionProvider.getcon();
					Statement st=con.createStatement();
					st.executeUpdate("DELETE FROM customerbill WHERE BillNo='"+Cbill+"'");
					JOptionPane.showMessageDialog(null,"Bill Successfully Deleted...");
					clear();
					autoID();
				}
				catch(Exception e1)
				{
				
				}
			}
		});
		btnDelete.setFont(new Font("Modern No. 20", Font.PLAIN, 17));
		btnDelete.setBounds(246, 419, 89, 23);
		contentPane.add(btnDelete);
		
		JButton btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clear();
				autoID();
			}
		});
		btnClear.setFont(new Font("Modern No. 20", Font.PLAIN, 17));
		btnClear.setBounds(354, 420, 89, 23);
		contentPane.add(btnClear);
		
		JButton btnPrint = new JButton("Print");
		btnPrint.setFont(new Font("Modern No. 20", Font.PLAIN, 17));
		btnPrint.setBounds(466, 420, 89, 23);
		contentPane.add(btnPrint);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnExit.setFont(new Font("Modern No. 20", Font.PLAIN, 17));
		btnExit.setBounds(571, 419, 89, 23);
		contentPane.add(btnExit);
		autoID();
	}
}
