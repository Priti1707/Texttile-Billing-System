import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import Project.ConnectionProvider;

import java.awt.Color;

@SuppressWarnings("serial")
public class SupplierDetails extends JFrame {

	private JPanel contentPane;
	private JTextField txtSuppID;
	private JTextField txtContNo;
	private JTextField txtAddress;
	private JTextField txtSuppName;
	private JTextField txtEmail;
	private JTextField txtSearch;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public void clear()
	{
		
		txtContNo.setText("");
		txtAddress.setText("");
		txtEmail.setText("");
		txtSearch.setText("");
		txtSuppName.setText("");
	}
	public void tableDetails()
	{
		DefaultTableModel dtm=(DefaultTableModel)table.getModel();
		
		table.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
		dtm.setRowCount(0);
		try
		{
			Connection con=ConnectionProvider.getcon();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from supplierdetails");
			while(rs.next())
			{
				dtm.addRow(new Object[] {rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5)});
			}
			
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null, e);
		}
		
	}
	private void autoID()
	{
		try
		{
			Connection con=ConnectionProvider.getcon();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select Max(SuppID) from supplierdetails ");
			rs.next();
			rs.getString("Max(SuppID)");
			if(rs.getString("Max(SuppID)")==null)
			{
				txtSuppID.setText("01");
			}
			else
			{
				Long id = Long.parseLong(rs.getString("Max(SuppID)").substring(0,rs.getString("Max(SuppID)").length()));
				id++;
				txtSuppID.setText("0" + String.format("%d",id));	
			}
		
		}
		catch(Exception e)
		{
			
			JOptionPane.showMessageDialog(null, e);
		}
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SupplierDetails frame = new SupplierDetails();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SupplierDetails() {
		setTitle("Supplier Details");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 695, 497);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 165, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 44, 659, 135);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Supplier ID :");
		
		lblNewLabel.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel.setBounds(10, 26, 95, 25);
		panel.add(lblNewLabel);
		
		JLabel lblContactNo = new JLabel("Contact No :");
		lblContactNo.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblContactNo.setBounds(10, 63, 95, 25);
		panel.add(lblContactNo);
		
		JLabel lblAddress = new JLabel("Address :");
		lblAddress.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblAddress.setBounds(10, 101, 95, 25);
		panel.add(lblAddress);
		
		JLabel lblSupplierName = new JLabel("Supplier Name :");
		lblSupplierName.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblSupplierName.setBounds(310, 26, 114, 25);
		panel.add(lblSupplierName);
		
		JLabel lblEmail = new JLabel("Email :");
		lblEmail.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblEmail.setBounds(310, 63, 114, 25);
		panel.add(lblEmail);
		
		JLabel lblSearchBy = new JLabel("Search By :");
		lblSearchBy.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblSearchBy.setBounds(310, 101, 114, 25);
		panel.add(lblSearchBy);
		
		txtSuppID = new JTextField();
		txtSuppID.setBounds(102, 28, 154, 20);
		panel.add(txtSuppID);
		txtSuppID.setColumns(10);
		
		txtContNo = new JTextField();
		txtContNo.setColumns(10);
		txtContNo.setBounds(102, 65, 154, 20);
		panel.add(txtContNo);
		
		txtAddress = new JTextField();
		txtAddress.setColumns(10);
		txtAddress.setBounds(102, 103, 154, 20);
		panel.add(txtAddress);
		
		txtSuppName = new JTextField();
		txtSuppName.setColumns(10);
		txtSuppName.setBounds(418, 28, 197, 20);
		panel.add(txtSuppName);
		
		txtEmail = new JTextField();
		txtEmail.setColumns(10);
		txtEmail.setBounds(418, 65, 154, 20);
		panel.add(txtEmail);
		
		txtSearch = new JTextField();
		txtSearch.setColumns(10);
		txtSearch.setBounds(418, 103, 127, 20);
		panel.add(txtSearch);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = txtSearch.getText();
				try {
					Connection con= ConnectionProvider.getcon();
					java.sql.Statement st= con.createStatement();
					ResultSet rs = ((java.sql.Statement) st).executeQuery("select * from supplierdetails where SuppID='"+id+"'");
					if(rs.next())
					{
						txtSuppID.setEditable(false);
						txtSuppID.setText(rs.getString(1));
						txtSuppName.setText(rs.getString(2));
						txtContNo.setText(rs.getString(3));
						txtEmail.setText(rs.getString(4));
						txtAddress.setText(rs.getString(5));
							
					}
					else 
					{
						JOptionPane.showMessageDialog(null, "Supplier does not Exist");
						clear();
						tableDetails();
						autoID();
					}
					
				}
				catch(Exception e1) {
					JOptionPane.showMessageDialog(null, e1);
				} 
			}
	
			
		});
		btnSearch.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		btnSearch.setBounds(560, 102, 89, 23);
		panel.add(btnSearch);
		
		JLabel lblNewLabel_1 = new JLabel("   Supplier Details");
		lblNewLabel_1.setFont(new Font("Modern No. 20", Font.PLAIN, 17));
		lblNewLabel_1.setBounds(262, 11, 150, 22);
		contentPane.add(lblNewLabel_1);
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id =  txtSuppID.getText();
				String name= txtSuppName.getText();
				 String Cont= txtContNo.getText();
				String email= txtEmail.getText();
			    String add= txtAddress.getText();
				 

				try
				{
					Connection con=ConnectionProvider.getcon();	
					PreparedStatement ps = con.prepareStatement("insert into supplierdetails values(?,?,?,?,?)");
					ps.setString(1,id);
					ps.setString(2,name);
					ps.setString(3,Cont);
					ps.setString(4,email);
					ps.setString(5,add);
					 
					ps.executeUpdate();
					JOptionPane.showMessageDialog(null,"Record SuccessFully Added...");
					tableDetails();
					clear(); 
					autoID();
					
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null, e1);
				}
			}	
		});
			
	
		btnSave.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		btnSave.setBounds(569, 197, 89, 23);
		contentPane.add(btnSave);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id =  txtSuppID.getText();
				String name= txtSuppName.getText();
				String Cont= txtContNo.getText();
				String email= txtEmail.getText();
		 	    String add=txtAddress.getText();
				 
				 
				try
				{
					Connection con=ConnectionProvider.getcon();
					PreparedStatement ps = con.prepareStatement("update supplierdetails set SuppID=?,SuppName=?,ContNo=?,Email=?,Address=? where SuppID='"+id+"'");
					ps.setString(1,id);
					ps.setString(2,name);
					ps.setString(3,Cont);
					ps.setString(4,email);
					ps.setString(5,add);
					
					ps.executeUpdate();
					JOptionPane.showMessageDialog(null,"Record Successfully Updated...");
					tableDetails();
					clear(); 
					autoID();
					
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null,e1);
				}
			}	
		});
			
		btnUpdate.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		btnUpdate.setBounds(569, 242, 89, 23);
		contentPane.add(btnUpdate);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		btnDelete.setBounds(569, 281, 89, 23);
		contentPane.add(btnDelete);
		
		JButton btnPrint = new JButton("Print");
		btnPrint.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		btnPrint.setBounds(569, 324, 89, 23);
		contentPane.add(btnPrint);
		
		JButton btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clear();
				autoID();
			}
		});
		btnClear.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		btnClear.setBounds(569, 358, 89, 23);
		contentPane.add(btnClear);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnExit.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		btnExit.setBounds(569, 392, 89, 23);
		contentPane.add(btnExit);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 226, 549, 221);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
			},
			new String[] {
				"SuppID", "SuppName", "ContNo", "Email", "Address"
			}
		));
		scrollPane.setViewportView(table);
		tableDetails();
		autoID();
	}
}
