package Project;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;

import com.toedter.calendar.JDateChooser;


import javax.swing.JTextArea;


@SuppressWarnings("serial")
public class SupplierBill extends JFrame {
	@SuppressWarnings({ "rawtypes" })
	private JComboBox comboOrderID;
	private JTextField txtBillNo;
	private JTextField txtBalance;
	private JTextField txtSuppID;
	private JTextField txtSuppName;
	private JTextField txtMatID;
	private JTextField txtMatName;
	private JTextField txtSize;
	private JTextField txtQuantity;
	private JTextField txtRate;
	private JTextField txtAdvance;
	private JTextField txtTotalEx;

	/**
	 * Launch the application.
	 */
	public void clear()
	{
		txtBillNo.setText("");
		comboOrderID.removeItemAt(0);
		txtSuppID.setText("");
		txtSuppName.setText("");
		txtMatID.setText("");
		txtMatName.setText("");
		txtSize.setText("");
		txtQuantity.setText("");
		txtRate.setText("");
		txtAdvance.setText("");
		txtBalance.setText("");
		txtTotalEx.setText("");
	}
	private void autoID()
	{
		try
		{
			Connection con=ConnectionProvider.getcon();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select Max(BillNo) from supplierbill ");
			rs.next();
			rs.getString("Max(BillNo)");
			if(rs.getString("Max(BillNo)")==null)
			{
				txtBillNo.setText("01");
			}
			else
			{
				Long id = Long.parseLong(rs.getString("Max(BillNo)").substring(0,rs.getString("Max(BillNo)").length()));
				id++;
				txtBillNo.setText("0" + String.format("%d",id));	
			}
		
		}
		catch(Exception e)
		{
			
			JOptionPane.showMessageDialog(null, e);
		}
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SupplierBill frame = new SupplierBill();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	@SuppressWarnings("unchecked")
	public SupplierBill() {
		setTitle ("Supplier Bill");
		getContentPane().setBackground(new Color(255, 165, 0));
		getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 11, 772, 139);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Supplier Information");
		lblNewLabel.setFont(new Font("Modern No. 20", Font.PLAIN, 16));
		lblNewLabel.setBounds(10, 11, 183, 14);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Bill No :");
		lblNewLabel_1.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(32, 47, 71, 14);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Supplier ID :");
		lblNewLabel_1_1.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1_1.setBounds(10, 95, 81, 14);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Order ID :");
		lblNewLabel_1_2.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1_2.setBounds(426, 47, 71, 14);
		panel.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Supplier Name :");
		lblNewLabel_1_3.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1_3.setBounds(397, 95, 114, 14);
		panel.add(lblNewLabel_1_3);
		
		txtBillNo = new JTextField();
		txtBillNo.setBounds(107, 44, 250, 27);
		panel.add(txtBillNo);
		txtBillNo.setColumns(10);
		
		@SuppressWarnings("rawtypes")
		JComboBox comboOrderID = new JComboBox();
		comboOrderID.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Oid =  comboOrderID.getSelectedItem().toString();
				try
				{
					Connection con= ConnectionProvider.getcon();
					java.sql.Statement st= con.createStatement();
					ResultSet rs = ((java.sql.Statement) st).executeQuery("select * from supplierorder where OrderID='"+Oid+"'");
					if(rs.next())
					{
						txtSuppID.setText(rs.getString(3));
						txtSuppName.setText(rs.getString(4));
						txtMatID.setText(rs.getString(5));
						txtMatName.setText(rs.getString(6));
						txtSize.setText(rs.getString(7));
						txtQuantity.setText(rs.getString(8));
							
					}
					else 
					{
						JOptionPane.showMessageDialog(null, "Supplier does not Exist");
						clear();
						
					}
					
				}
				catch(Exception e1)
				{
					
				
				}
			}
		});
		comboOrderID.setBounds(507, 43, 248, 28);
		comboOrderID.setEditable(true);
		panel.add(comboOrderID);
		
		try
		{
			int i = 0;
			Connection con = ConnectionProvider.getcon();
			Statement st = con.createStatement();
			
			ResultSet rs=st.executeQuery("select * from supplierorder ");
				
			
			while(rs.next())
			{		
				i = 1 ;
				comboOrderID.addItem(rs.getString("OrderID")); 
			}
			con.close();
			if(i==0)
			{
				 
				JOptionPane.showMessageDialog(null,"Supplier Order ID Not Available");
				
			}
		}
		catch(Exception e)
		{
			
		}
		
		txtSuppID = new JTextField();
		txtSuppID.setColumns(10);
		txtSuppID.setBounds(107, 92, 250, 27);
		panel.add(txtSuppID);
		
		txtSuppName = new JTextField();
		txtSuppName.setColumns(10);
		txtSuppName.setBounds(508, 92, 247, 27);
		panel.add(txtSuppName);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(10, 161, 388, 201);
		getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblTotal = new JLabel("Material Details ");
		lblTotal.setFont(new Font("Modern No. 20", Font.PLAIN, 16));
		lblTotal.setBounds(10, 11, 183, 14);
		panel_1.add(lblTotal);
		
		JLabel lblNewLabel_2 = new JLabel("Material ID :");
		lblNewLabel_2.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(41, 38, 92, 23);
		panel_1.add(lblNewLabel_2);
		
		txtMatID = new JTextField();
		txtMatID.setColumns(10);
		txtMatID.setBounds(147, 39, 217, 22);
		panel_1.add(txtMatID);
		
		JLabel lblNewLabel_2_1 = new JLabel("Material Name :");
		lblNewLabel_2_1.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_2_1.setBounds(25, 72, 113, 23);
		panel_1.add(lblNewLabel_2_1);
		
		txtMatName = new JTextField();
		txtMatName.setColumns(10);
		txtMatName.setBounds(148, 73, 216, 22);
		panel_1.add(txtMatName);
		
		JLabel lblNewLabel_2_2 = new JLabel("Size :");
		lblNewLabel_2_2.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_2_2.setBounds(90, 106, 61, 23);
		panel_1.add(lblNewLabel_2_2);
		
		txtSize = new JTextField();
		txtSize.setColumns(10);
		txtSize.setBounds(147, 107, 217, 23);
		panel_1.add(txtSize);
		
		JLabel lblNewLabel_2_3 = new JLabel("Quantity (Box) :");
		lblNewLabel_2_3.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_2_3.setBounds(20, 140, 118, 23);
		panel_1.add(lblNewLabel_2_3);
		
		txtQuantity = new JTextField();
		txtQuantity.setColumns(10);
		txtQuantity.setBounds(147, 140, 217, 21);
		panel_1.add(txtQuantity);
		
		JLabel lblNewLabel_2_2_1 = new JLabel("Rate :");
		lblNewLabel_2_2_1.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_2_2_1.setBounds(90, 167, 61, 23);
		panel_1.add(lblNewLabel_2_2_1);
		
		txtRate = new JTextField();
		txtRate.setColumns(10);
		txtRate.setBounds(147, 168, 217, 22);
		panel_1.add(txtRate);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(413, 161, 369, 201);
		getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblTotal_1 = new JLabel("Total");
		lblTotal_1.setFont(new Font("Modern No. 20", Font.PLAIN, 16));
		lblTotal_1.setBounds(10, 11, 183, 14);
		panel_2.add(lblTotal_1);
		
		JLabel lblNewLabel_1_6_1 = new JLabel("Date :");
		lblNewLabel_1_6_1.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1_6_1.setBounds(67, 108, 45, 14);
		panel_2.add(lblNewLabel_1_6_1);
		
		JLabel lblNewLabel_1_6_2 = new JLabel("Balance :");
		lblNewLabel_1_6_2.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1_6_2.setBounds(47, 39, 72, 14);
		panel_2.add(lblNewLabel_1_6_2);
		
		txtBalance = new JTextField();
		txtBalance.setColumns(10);
		txtBalance.setBounds(119, 36, 235, 25);
		panel_2.add(txtBalance);
		
		JButton btnCalulate = new JButton("Calculation");
		btnCalulate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int advance= Integer.parseInt(txtAdvance.getText());
				int Rate= Integer.parseInt(txtRate.getText());
				int Quant= Integer.parseInt(txtQuantity.getText());  
				String Total= String.valueOf(Quant*Rate);
				txtTotalEx.setText(Total);
				int Total1= Integer.parseInt(txtTotalEx.getText());
				String balance= String.valueOf(Total1 - advance);
				txtBalance.setText(balance);
			}
		});
		btnCalulate.setFont(new Font("Modern No. 20", Font.PLAIN, 18));
		btnCalulate.setBounds(157, 167, 128, 34);
		panel_2.add(btnCalulate);
		
		JLabel lblNewLabel_2_2_1_1 = new JLabel("Advance :");
		lblNewLabel_2_2_1_1.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_2_2_1_1.setBounds(47, 64, 61, 23);
		panel_2.add(lblNewLabel_2_2_1_1);
		
		JLabel lblNewLabel_2_2_1_2 = new JLabel("Total Expanses :");
		lblNewLabel_2_2_1_2.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_2_2_1_2.setBounds(20, 133, 105, 23);
		panel_2.add(lblNewLabel_2_2_1_2);
		
		txtAdvance = new JTextField();
		txtAdvance.setColumns(10);
		txtAdvance.setBounds(119, 67, 235, 28);
		panel_2.add(txtAdvance);
		
		txtTotalEx = new JTextField();
		txtTotalEx.setColumns(10);
		txtTotalEx.setBounds(119, 134, 235, 25);
		panel_2.add(txtTotalEx);
		
		JDateChooser txtdateChooser = new JDateChooser();
		txtdateChooser.setBounds(119, 101, 235, 25);
		panel_2.add(txtdateChooser);
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Sbill= txtBillNo.getText();
				String Oid =  comboOrderID.getSelectedItem().toString();
				String Sid= txtSuppID.getText();
				String Sname= txtSuppName.getText();;
			    String Mid= txtMatID.getText();
			    String Mname= txtMatName.getText();
			    String size=txtSize.getText();
			    String Quant= txtQuantity.getText();
			    String Rate=txtRate.getText();
			    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				String date= sdf.format(txtdateChooser.getDate());
			    String advance= txtAdvance.getText();
			    String balance= txtBalance.getText();
			    String Total= txtTotalEx.getText();
			   
				try
				{
					Connection con=ConnectionProvider.getcon();	
					PreparedStatement ps = con.prepareStatement("insert into supplierbill values(?,?,?,?,?,?,?,?,?,?,?,?,?)");
					ps.setString(1,Sbill);
					ps.setString(2,Oid);
					ps.setString(3,Sid);
					ps.setString(4,Sname);
					ps.setString(5,Mid);
					ps.setString(6,Mname);
					ps.setString(7,size);
					ps.setString(8,Quant);
					ps.setString(9,Rate);
					ps.setString(10,date);
					ps.setString(11,advance);
					ps.setString(12,balance);
					ps.setString(13,Total);
			 
					ps.executeUpdate();
					JOptionPane.showMessageDialog(null,"Supplier Bill SuccessFully Added...");
				
					clear(); 
					autoID();
					
				}
				catch(Exception e1)
				{
				
				}
			}
		});
		btnSave.setFont(new Font("Modern No. 20", Font.PLAIN, 19));
		btnSave.setBounds(20, 383, 105, 29);
		getContentPane().add(btnSave);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Sbill=txtBillNo.getText();
				try
				{
					Connection con=ConnectionProvider.getcon();
					Statement st=con.createStatement();
					st.executeUpdate("DELETE FROM supplierbill WHERE BillNo='"+Sbill+"'");
					JOptionPane.showMessageDialog(null,"Bill Successfully Deleted...");
					clear();
					autoID();
				}
				catch(Exception e1)
				{
				
				}
			}
		});
		btnDelete.setFont(new Font("Modern No. 20", Font.PLAIN, 19));
		btnDelete.setBounds(264, 383, 105, 29);
		getContentPane().add(btnDelete);
		
		JButton btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clear();
				autoID();
			}
		});
		btnClear.setFont(new Font("Modern No. 20", Font.PLAIN, 19));
		btnClear.setBounds(395, 383, 105, 29);
		getContentPane().add(btnClear);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(792, 11, 365, 401);
		getContentPane().add(panel_3);
		panel_3.setLayout(null);
		
		JTextArea billprint = new JTextArea();
		billprint.setFont(new Font("Cambria", Font.PLAIN, 18));
		billprint.setBounds(10, 11, 345, 379);
		panel_3.add(billprint);
		
		JButton btnPrint = new JButton("Print");
		btnPrint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				billprint.setText("");
				billprint.append("\tSupplier Bill\n"
						+ "**************************************\n"
						+"Bill No\t:\t"+txtBillNo.getText()
						+"\nCustomer Name : "+txtSuppName.getText()
						+"\nCustomer ID\t:\t"+txtSuppID.getText()
						+"\n\n***************************************\n"
						+"\nMaterial ID\t:\t"+txtMatID.getText()
						+"\nMaterial Name : "+txtMatName.getText()
						+"\nSize\t :\t"+txtSize.getText()
						+ "\nQuantity\t:\t"+txtQuantity.getText()
						+"\nRate\t:\t"+txtRate.getText()
						+"\n*********************************"
						+"\nAdvance\t:\t"+txtAdvance.getText()
						+"\nBalance\t:\t"+txtBalance.getText()
						+"\nTotal\t:\t"+txtTotalEx.getText()
						);
				
			}
		});
		btnPrint.setFont(new Font("Modern No. 20", Font.PLAIN, 19));
		btnPrint.setBounds(529, 383, 105, 29);
		getContentPane().add(btnPrint);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnExit.setBackground(Color.WHITE);
		btnExit.setFont(new Font("Modern No. 20", Font.PLAIN, 19));
		btnExit.setBounds(663, 383, 105, 29);
		getContentPane().add(btnExit);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Sbill= txtBillNo.getText();
				String Oid =  comboOrderID.getSelectedItem().toString();
				String Sid= txtSuppID.getText();
				String Sname= txtSuppName.getText();
			    String Mid= txtMatID.getText();
			    String Mname= txtMatName.getText();
			    String size=txtSize.getText();
			    String Quant= txtQuantity.getText();
			    String Rate=txtRate.getText();
			    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				String date= sdf.format(txtdateChooser.getDate());
			    String advance= txtAdvance.getText();
			    String balance= txtBalance.getText();
			    String Total= txtTotalEx.getText();
			   
				try
				{
					Connection con=ConnectionProvider.getcon();	
					PreparedStatement ps = con.prepareStatement("update supplierbill set BillNo=?,OrderID=?,CustID=?,CustName=?,MatID=?,MatName=?,Size=?,Quantity=?,Rate=?,Date=?,Advance=?,Balance=?,TotalEx=? where BillNo='"+Sbill+"'");
					ps.setString(1,Sbill);
					ps.setString(2,Oid);
					ps.setString(3,Sid);
					ps.setString(4,Sname);
					ps.setString(5,Mid);
					ps.setString(6,Mname);
					ps.setString(7,size);
					ps.setString(8,Quant);
					ps.setString(9,Rate);
					ps.setString(10,date);
					ps.setString(11,advance);
					ps.setString(12,balance);
					ps.setString(13,Total);
			 
					ps.executeUpdate();
					JOptionPane.showMessageDialog(null,"Supplier Bill SuccessFully Updated...");
				
					clear(); 
					autoID();
					
				}
				catch(Exception e1)
				{
				
				}
			}
		});
		
		btnUpdate.setFont(new Font("Modern No. 20", Font.PLAIN, 19));
		btnUpdate.setBounds(135, 383, 105, 29);
		getContentPane().add(btnUpdate);
		
		
	}
}
