package Project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import com.toedter.calendar.JDateChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
//import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import java.awt.Color;
//import com.toedter.calendar.JYearChooser;


import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

public class MonthlyReport extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MonthlyReport frame = new MonthlyReport();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MonthlyReport() {
		setTitle("Monthly Reports");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 394, 361);
		contentPane = new JPanel();
		contentPane.setBackground(Color.ORANGE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("From :");
		lblNewLabel.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel.setBounds(21, 38, 46, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("To :");
		lblNewLabel_1.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(21, 110, 46, 14);
		contentPane.add(lblNewLabel_1);
		
		JDateChooser datechooser1 = new JDateChooser();
		datechooser1.setBounds(87, 38, 167, 24);
		contentPane.add(datechooser1);
		
		JDateChooser datechooser2 = new JDateChooser();
		datechooser2.setBounds(88, 110, 166, 24);
		contentPane.add(datechooser2);
		
		JButton CustomerReport = new JButton("Customer Monthly Report");
		CustomerReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					 Class.forName("com.mysql.cj.jdbc.Driver");
					 Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/textilebilling","root","root");
					 String sql= "select * from customerbill where Date between'"+datechooser1.getDateEditor()+"' AND '"+ datechooser2.getDateEditor()+"'";
					 
					 JasperDesign jdesign= JRXmlLoader.load("C:\\Users\\Dell\\eclipse-workspace\\TextileBillingSystem\\src\\Project\\CustomerMonthlyRp.jrxml");
					 JRDesignQuery updateQuery = new JRDesignQuery();
					 
					 updateQuery.setText(sql);
					 jdesign.setQuery(updateQuery);
					 
					 JasperReport jreport = JasperCompileManager.compileReport(jdesign);
					 JasperPrint JasperPrint =JasperFillManager.fillReport(jreport,null,con);
					 JasperViewer.viewReport(JasperPrint,false);
					 
					
				}
			catch(Exception e1) {
				JOptionPane.showMessageDialog(null,e1);
			}
				
				
			}
		});
		CustomerReport.setFont(new Font("Modern No. 20", Font.PLAIN, 18));
		CustomerReport.setBounds(63, 227, 235, 29);
		contentPane.add(CustomerReport);
		
	
	}
}
