package Project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.Color;
import com.toedter.calendar.JDateChooser;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;



public class SupplierOrder extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	@SuppressWarnings("rawtypes")
	private JComboBox comboSuppID;
	@SuppressWarnings("rawtypes")
	private JComboBox comboSuppName;
	@SuppressWarnings("rawtypes")
	private JComboBox comboMatName;
	@SuppressWarnings("rawtypes")
	private JComboBox comboSize;
	private JTextField txtOrderID;
	private JTextField txtQuantity;
	private JTextField txtMatID;

	/**
	 * Launch the application.
	 */
	public void clear()
	{
		txtOrderID.setText("");
		comboSuppID.removeItemAt(0);
		comboSuppName.removeItemAt(0);
		txtMatID.setText("");
		comboMatName.removeItemAt(0);
		comboSize.removeItemAt(0);
		txtQuantity.setText("");
	}
	private void autoID()
	{
		try
		{
			Connection con=ConnectionProvider.getcon();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select Max(OrderID) from supplierorder ");
			rs.next();
			rs.getString("Max(OrderID)");
			if(rs.getString("Max(OrderID)")==null)
			{
				txtOrderID.setText("01");
			}
			else
			{
				Long id = Long.parseLong(rs.getString("Max(OrderID)").substring(0,rs.getString("Max(OrderID)").length()));
				id++;
				txtOrderID.setText("0" + String.format("%d",id));	
			}
		
		}
		catch(Exception e)
		{
			
			JOptionPane.showMessageDialog(null, e);
		}
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SupplierOrder frame = new SupplierOrder();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public SupplierOrder() {
		setTitle("Supplier Order");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 746, 499);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 165, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 11, 714, 157);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblSupplierDetails = new JLabel("Supplier Details ");
		lblSupplierDetails.setFont(new Font("Modern No. 20", Font.PLAIN, 16));
		lblSupplierDetails.setBounds(10, 11, 136, 17);
		panel.add(lblSupplierDetails);
		
		JLabel lblNewLabel_1 = new JLabel("Supplier Order ID :- ");
		lblNewLabel_1.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(10, 53, 136, 17);
		panel.add(lblNewLabel_1);
		
		txtOrderID = new JTextField();
		txtOrderID.setColumns(10);
		txtOrderID.setBounds(149, 51, 196, 30);
		panel.add(txtOrderID);
		
		JLabel lblNewLabel_1_1 = new JLabel("Supplier ID :-");
		lblNewLabel_1_1.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1_1.setBounds(49, 109, 97, 17);
		panel.add(lblNewLabel_1_1);
		
		JComboBox comboSuppID = new JComboBox();
		comboSuppID.setFont(new Font("Modern No. 20", Font.PLAIN, 16));
		comboSuppID.setBounds(149, 106, 196, 28);
		comboSuppID.setEditable(true);
		panel.add(comboSuppID);
		try
		{
			int i = 0;
			Connection con = ConnectionProvider.getcon();
			Statement st = con.createStatement();
			
			ResultSet rs=st.executeQuery("select * from suppdetails ");
				
			
			while(rs.next())
			{		
				i = 1 ;
				comboSuppID.addItem(rs.getString("SuppID")); 
			}
			con.close();
			if(i==0)
			{
				 
				JOptionPane.showMessageDialog(null,"Supplier ID Not Available");
				
			}
		}
		catch(Exception e)
		{
			
		}
		
		
		JLabel lblNewLabel_1_3 = new JLabel("Supplier Name :-");
		lblNewLabel_1_3.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1_3.setBounds(372, 109, 125, 17);
		panel.add(lblNewLabel_1_3);
		
		JComboBox comboSuppName = new JComboBox();
		comboSuppName.setBounds(488, 105, 210, 28);
		comboSuppName.setEditable(true);
		panel.add(comboSuppName);
		try
		{
			int i = 0;
			Connection con = ConnectionProvider.getcon();
			Statement st = con.createStatement();
			
			ResultSet rs=st.executeQuery("select * from suppdetails ");
				
			
			while(rs.next())
			{		
				i = 1 ;
				comboSuppName.addItem(rs.getString("SuppName")); 
			}
			con.close();
			if(i==0)
			{
				 
				JOptionPane.showMessageDialog(null,"Supplier Name Not Available");
				
			}
		}
		catch(Exception e)
		{
			
		}
		
		
		JLabel lblNewLabel_1_2 = new JLabel("Date :-");
		lblNewLabel_1_2.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1_2.setBounds(430, 53, 61, 17);
		panel.add(lblNewLabel_1_2);
		
		JDateChooser txtdateChooser = new JDateChooser();
		txtdateChooser.setBounds(485, 47, 210, 28);
		panel.add(txtdateChooser);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(10, 179, 716, 219);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblMaterialDetails = new JLabel("Material Details ");
		lblMaterialDetails.setFont(new Font("Modern No. 20", Font.PLAIN, 16));
		lblMaterialDetails.setBounds(10, 11, 136, 17);
		panel_1.add(lblMaterialDetails);
		
		JLabel lblNewLabel_1_4 = new JLabel("Material Name :-");
		lblNewLabel_1_4.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1_4.setBounds(20, 53, 109, 17);
		panel_1.add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_5 = new JLabel("Material ID :-");
		lblNewLabel_1_5.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1_5.setBounds(37, 96, 97, 17);
		panel_1.add(lblNewLabel_1_5);
		
		JLabel lblNewLabel_1_6 = new JLabel("Size :-");
		lblNewLabel_1_6.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1_6.setBounds(87, 141, 52, 17);
		panel_1.add(lblNewLabel_1_6);
		
		JLabel lblNewLabel_1_7 = new JLabel(" Quantity :-");
		lblNewLabel_1_7.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1_7.setBounds(47, 189, 89, 17);
		panel_1.add(lblNewLabel_1_7);
		
		txtQuantity = new JTextField();
		txtQuantity.setColumns(10);
		txtQuantity.setBounds(145, 187, 307, 27);
		panel_1.add(txtQuantity);
		
		txtMatID = new JTextField();
		txtMatID.setColumns(10);
		txtMatID.setBounds(145, 94, 307, 29);
		panel_1.add(txtMatID);
		
		JComboBox comboMatName = new JComboBox();
		comboMatName.setModel(new DefaultComboBoxModel(new String[] {"Fibre", "Yarn ", "Fabric", "Dyes", "Chemicals and Auxiliaries", "Zips"}));
		comboMatName.setFont(new Font("Modern No. 20", Font.PLAIN, 16));
		comboMatName.setEditable(true);
		comboMatName.setBounds(145, 50, 307, 29);
		panel_1.add(comboMatName);
		
		JComboBox comboSize = new JComboBox();
		comboSize.setModel(new DefaultComboBoxModel(new String[] {"10", "20", "30", "40", "50", "60", "70", "80", "90", "100"}));
		comboSize.setFont(new Font("Modern No. 20", Font.PLAIN, 16));
		comboSize.setEditable(true);
		comboSize.setBounds(145, 138, 307, 31);
		panel_1.add(comboSize);
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Oid =  txtOrderID.getText();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				String date= sdf.format(txtdateChooser.getDate());
				String Sid= comboSuppID.getSelectedItem().toString();
				String Sname= comboSuppName.getSelectedItem().toString();
			    String Mid= txtMatID.getText();
			    String Mname= comboMatName.getSelectedItem().toString();
			    String size=comboSize.getSelectedItem().toString();
			    String Quant= txtQuantity.getText();

				try
				{
					Connection con=ConnectionProvider.getcon();	
					PreparedStatement ps = con.prepareStatement("insert into supplierorder values(?,?,?,?,?,?,?,?)");
					ps.setString(1,Oid);
					ps.setString(2,date);
					ps.setString(3,Sid);
					ps.setString(4,Sname);
					ps.setString(5,Mid);
					ps.setString(6,Mname);
					ps.setString(7,size);
					ps.setString(8,Quant);
			 
					ps.executeUpdate();
					JOptionPane.showMessageDialog(null,"Supplier Order SuccessFully Added...");
				
					clear(); 
					autoID();
					
				}
				catch(Exception e1)
				{
				}					
			}
		});
		btnSave.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		btnSave.setBounds(18, 421, 89, 32);
		contentPane.add(btnSave);
		
		JButton btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clear();
				autoID();
			}
		});
		btnClear.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		btnClear.setBounds(259, 419, 89, 32);
		contentPane.add(btnClear);
		
		JButton btnPrint = new JButton("Print");
		btnPrint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					 Class.forName("com.mysql.cj.jdbc.Driver");
					 Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/textilebilling","root","root");
					 String sql= "select * from supplierorder";
					 
					 JasperDesign jdesign= JRXmlLoader.load("C:\\Users\\Dell\\eclipse-workspace\\TextileBillingSystem\\src\\Project\\SupplierOrderRp.jrxml");
					 JRDesignQuery updateQuery = new JRDesignQuery();
					 
					 updateQuery.setText(sql);
					 jdesign.setQuery(updateQuery);
					 
					 JasperReport jreport = JasperCompileManager.compileReport(jdesign);
					 JasperPrint JasperPrint =JasperFillManager.fillReport(jreport,null,con);
					 JasperViewer.viewReport(JasperPrint,false);
					 
					
				}
			catch(Exception e1) {
				JOptionPane.showMessageDialog(null,e1);
			}
			}
		});
		
		btnPrint.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		btnPrint.setBounds(493, 423, 89, 32);
		contentPane.add(btnPrint);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnExit.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		btnExit.setBounds(607, 418, 89, 34);
		contentPane.add(btnExit);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Oid =  txtOrderID.getText();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				String date= sdf.format(txtdateChooser.getDate());
				String Sid= comboSuppID.getSelectedItem().toString();
				String Sname= comboSuppName.getSelectedItem().toString();
			    String Mid= txtMatID.getText();
			    String Mname= comboMatName.getSelectedItem().toString();
			    String size=comboSize.getSelectedItem().toString();
			    String Quant= txtQuantity.getText();

				try
				{
					Connection con=ConnectionProvider.getcon();	
					PreparedStatement ps = con.prepareStatement("update supplierorder set OrderID=?,Date=?,SuppID=?,SuppName=?,MatID=?,MatName=?,Size=?,Quantity=? where OrderID='"+Oid+"'");
					ps.setString(1,Oid);
					ps.setString(2,date);
					ps.setString(3,Sid);
					ps.setString(4,Sname);
					ps.setString(5,Mid);
					ps.setString(6,Mname);
					ps.setString(7,size);
					ps.setString(8,Quant);
			 
					ps.executeUpdate();
					JOptionPane.showMessageDialog(null,"Supplier Order SuccessFully Updated...");
				
					clear(); 
					autoID();
					
				}
				catch(Exception e1)
				{
					
				}

			}
		});
		btnUpdate.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		btnUpdate.setBounds(138, 420, 91, 32);
		contentPane.add(btnUpdate);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Oid=txtOrderID.getText();
				try
				{
					Connection con=ConnectionProvider.getcon();
					Statement st=con.createStatement();
					st.executeUpdate("DELETE FROM supplierorder WHERE OrderID='"+Oid+"'");
					JOptionPane.showMessageDialog(null,"Order Successfully Deleted...");
					clear();
					autoID();
				}
				catch(Exception e1)
				{
				
				}
			}
		});
		btnDelete.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		btnDelete.setBounds(373, 421, 89, 32);
		contentPane.add(btnDelete);
	}
}
