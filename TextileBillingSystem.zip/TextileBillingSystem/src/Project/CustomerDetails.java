package Project;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;


import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

//import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;
import net.sf.jasperreports.engine.JasperPrint;




public class CustomerDetails extends JFrame {
	
	private static final long serialVersionUID = 1L;
	protected static final JOptionPane OptionPane = null;
	private JPanel contentPane;
	private JTextField txtCustID;
	private JTextField txtContNo;
	private JTextField txtAddress;
	private JTextField txtCustName;
	private JTextField txtEmail;
	private JTextField txtSearcg;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public void clear()
	{ 
		txtContNo.setText("");
		txtAddress.setText("");
		txtEmail.setText("");
		txtSearcg.setText("");
		txtCustName.setText("");
		
	}
	public void tableDetails()
	{
		DefaultTableModel dtm=(DefaultTableModel)table.getModel();
		table.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
		dtm.setRowCount(0);
		try
		{
			Connection con=ConnectionProvider.getcon();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from customerdetails");
			while(rs.next())
			{
				dtm.addRow(new Object[] {rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5)});
			}
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null,e);
		}
		}
	private void autoID()
	{
		try
		{
			Connection con=ConnectionProvider.getcon();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select Max(CustID) from customerdetails");
			rs.next();
			rs.getString("Max(CustID)");
			if(rs.getString("Max(CustID)")==null)
			{
				txtCustID.setText("01");
				
			}
			else
			{
				Long id = Long.parseLong(rs.getString("Max(CustID)").substring(0,rs.getString("Max(CustID)").length()));
				id++;
				txtCustID.setText("0" + String.format("%d",id));	
				
			}
		}
			catch(Exception e) 
			{
				JOptionPane.showMessageDialog(null, e);
			}
		}
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
				    CustomerDetails frame = new CustomerDetails();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CustomerDetails() {
		setTitle("Customer Details");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 870, 497);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 165, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("    Customer Details");
		lblNewLabel.setBounds(328, 11, 168, 39);
		lblNewLabel.setFont(new Font("Modern No. 20", Font.PLAIN, 18));
		contentPane.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBounds(27, 43, 790, 164);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Customer ID :");
		lblNewLabel_1.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(10, 11, 89, 21);
		panel.add(lblNewLabel_1);
		
		txtCustID = new JTextField();
		txtCustID.setBounds(109, 11, 217, 31);
		panel.add(txtCustID);
		txtCustID.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Contact No :");
		lblNewLabel_2.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(20, 67, 89, 21);
		panel.add(lblNewLabel_2);
		
		txtContNo = new JTextField();
		txtContNo.setBounds(109, 67, 217, 31);
		panel.add(txtContNo);
		txtContNo.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Address :");
		lblNewLabel_3.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(37, 117, 72, 17);
		panel.add(lblNewLabel_3);
		
		txtAddress = new JTextField();
		txtAddress.setBounds(109, 115, 217, 31);
		panel.add(txtAddress);
		txtAddress.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Customer Name :");
		lblNewLabel_4.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_4.setBounds(349, 12, 101, 18);
		panel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Email :");
		lblNewLabel_5.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_5.setBounds(401, 68, 72, 18);
		panel.add(lblNewLabel_5);
		
		JLabel lblNewLabel_5_1 = new JLabel("Search By :");
		lblNewLabel_5_1.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_5_1.setBounds(376, 117, 86, 18);
		panel.add(lblNewLabel_5_1);
		
		txtCustName = new JTextField();
		txtCustName.setBounds(492, 11, 215, 31);
		panel.add(txtCustName);
		txtCustName.setColumns(10);
		
		txtEmail = new JTextField();
		txtEmail.setBounds(492, 67, 215, 31);
		panel.add(txtEmail);
		txtEmail.setColumns(10);
		
		txtSearcg = new JTextField();
		txtSearcg.setBounds(492, 116, 179, 30);
		panel.add(txtSearcg);
		txtSearcg.setColumns(10);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.setToolTipText("");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				  String id = txtSearcg.getText();
					try {
						Connection con= ConnectionProvider.getcon();
						java.sql.Statement st= con.createStatement();
						ResultSet rs = ((java.sql.Statement) st).executeQuery("select * from customerdetails where CustID='"+id+"'");
						if(rs.next())
						{
							txtCustID.setEditable(false);
							txtCustID.setText(rs.getString(1));
							txtCustName.setText(rs.getString(2));
							txtContNo.setText(rs.getString(3));
							txtEmail.setText(rs.getString(4));
							txtAddress.setText(rs.getString(5));
								
						}
						else 
						{
							JOptionPane.showMessageDialog(null, "Customer does not Exist");
							clear();
							tableDetails();
							autoID();
						}
						
					}
					catch(Exception e1) {
						JOptionPane.showMessageDialog(null, e1);
					} 
				}
		});
		btnSearch.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		btnSearch.setBounds(681, 115, 99, 31);
		panel.add(btnSearch);
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id =  txtCustID.getText();
				String cust= txtCustName.getText();
				 String Cont= txtContNo.getText();
				String email= txtEmail.getText();
			    String add=txtAddress.getText();
				 

				try
				{
					Connection con=ConnectionProvider.getcon();	
					PreparedStatement ps = con.prepareStatement("insert into customerdetails values(?,?,?,?,?)");
					ps.setString(1,id);
					ps.setString(2,cust);
					ps.setString(3,Cont);
					ps.setString(4,email);
					ps.setString(5,add);
					ps.executeUpdate();
					JOptionPane.showMessageDialog(null,"Record SuccessFully Added...");
					tableDetails();
					clear(); 
					autoID();
					
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null, e1);
				}
			}
		}
		);
		btnSave.setBounds(728, 218, 89, 30);
		btnSave.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		contentPane.add(btnSave);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id =  txtCustID.getText();
				String cust= txtCustName.getText();
				String Cont= txtContNo.getText();
				String email= txtEmail.getText();
		 	    String add=	txtAddress.getText();
				 
				 
				try
				{
					Connection con=ConnectionProvider.getcon();
					PreparedStatement ps = con.prepareStatement("update customerdetails set CustID=?,CustName=?,ContNo=?,Email=?,Address=? where CustID='"+id+"'");
					ps.setString(1,id);
					ps.setString(2,cust);
					ps.setString(3,Cont);
					ps.setString(4,email);
					ps.setString(5,add);
					
					ps.executeUpdate();
					JOptionPane.showMessageDialog(null,"Record Successfully Updated...");
					tableDetails();
					clear(); 
					autoID();
					
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null,e1);
				}
			}	
		});
		
		btnUpdate.setBounds(728, 259, 89, 30);
		btnUpdate.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		contentPane.add(btnUpdate);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		
				String id=txtCustID.getText();
				try
				{
					Connection con=ConnectionProvider.getcon();
					Statement st=con.createStatement();
					st.executeUpdate("DELETE FROM customerdetails WHERE CustID='"+id+"'");
					JOptionPane.showMessageDialog(null,"Record Successfully Deleted...");
					tableDetails();
					clear();
					autoID();
				}
				catch(Exception e1)
				{
				
				}
			}
		});
		btnDelete.setBounds(728, 300, 89, 30);
		btnDelete.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		contentPane.add(btnDelete);
		
		JButton btnPrint = new JButton("Print");
		btnPrint.addActionListener(new ActionListener() {
		
				public void actionPerformed(ActionEvent e) {
				try {
					 Class.forName("com.mysql.cj.jdbc.Driver");
					 Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/textilebilling","root","root");
					 String sql= "select * from customerdetails";
					 
					 JasperDesign jdesign= JRXmlLoader.load("C:\\Users\\Dell\\eclipse-workspace\\TextileBillingSystem\\src\\Project\\CustomerDetailsRp.jrxml");
					 JRDesignQuery updateQuery = new JRDesignQuery();
					 
					 updateQuery.setText(sql);
					 jdesign.setQuery(updateQuery);
					 
					 JasperReport jreport = JasperCompileManager.compileReport(jdesign);
					 JasperPrint JasperPrint =JasperFillManager.fillReport(jreport,null,con);
					 JasperViewer.viewReport(JasperPrint,false);
					 
					
				}
			catch(Exception e1) {
				JOptionPane.showMessageDialog(null,e1);
			}
			}
		});
		btnPrint.setBounds(728, 375, 89, 30);
		btnPrint.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		contentPane.add(btnPrint);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(0, 233, 675, 245);
		contentPane.add(scrollPane_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane_1.setViewportView(scrollPane);
		
		table = new JTable();
		//table.setFont(new Font("Modern No. 20", Font.BOLD, 12));
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
			},
			new String[] {
				" CustId", "CustName", "ContNo", " Email", "Address"
			}
		));
		scrollPane.setViewportView(table);
		tableDetails();
		autoID();
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnExit.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		btnExit.setBounds(728, 424, 89, 23);
		contentPane.add(btnExit);
		
		
		JButton btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clear();
				autoID();
			}
		});
		btnClear.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		btnClear.setBounds(728, 341, 89, 23);
		contentPane.add(btnClear);
	}
}
