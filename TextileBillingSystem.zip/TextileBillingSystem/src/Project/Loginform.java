package Project;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
public class Loginform extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textuser;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Loginform frame = new Loginform();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void clear() {
		textuser.setText("");
		passwordField.setText("");
	}

	/**
	 * Create the frame.
	 */
	public Loginform() {
		setForeground(new Color(240, 240, 240));
		setBackground(new Color(240, 240, 240));
		setAlwaysOnTop(true);
		setTitle("Login ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 535, 478);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Textile Billing System");
		lblNewLabel.setForeground(Color.BLUE);
		lblNewLabel.setLabelFor(this);
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setFont(new Font("Modern No. 20", Font.BOLD, 30));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(98, 28, 325, 32);
		contentPane.add(lblNewLabel);
		
		JLabel Username = new JLabel("Username");
		Username.setForeground(Color.BLACK);
		Username.setBackground(Color.WHITE);
		Username.setHorizontalAlignment(SwingConstants.CENTER);
		Username.setFont(new Font("Modern No. 20", Font.BOLD, 25));
		Username.setBounds(53, 124, 137, 19);
		contentPane.add(Username);
		
		textuser = new JTextField();
		textuser.setFont(new Font("Sylfaen", Font.BOLD, 15));
		textuser.setBounds(284, 121, 200, 32);
		contentPane.add(textuser);
		textuser.setColumns(10);
		
		JButton btnlogin = new JButton("Login");
		btnlogin.setFont(new Font("Modern No. 20", Font.BOLD, 25));
		btnlogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Username = textuser.getText();
				@SuppressWarnings("deprecation")
				String Password = passwordField.getText();
				try {
					Connection con = ConnectionProvider.getcon();
					Statement st = con.createStatement();
					ResultSet rs = st.executeQuery(" select * from login where Username = '"+Username+"'and Password = '"+Password+"'");
					if(rs.next())
					{
						setVisible(false);
						JOptionPane.showMessageDialog(null,"Login Successfully...");
					    new Main().setVisible(true);
						clear();
					}
					else
					{
						JOptionPane.showMessageDialog(null,"incorrect Username Or Password");
						clear();
					}
				}
				catch(Exception e1) {
					JOptionPane.showMessageDialog(null, e1);
				}
	
			}

			
		});
		btnlogin.setBounds(70, 344, 109, 32);
		contentPane.add(btnlogin);
		
		JLabel Password = new JLabel("Password");
		Password.setBackground(Color.WHITE);
		Password.setHorizontalAlignment(SwingConstants.CENTER);
		Password.setFont(new Font("Modern No. 20", Font.BOLD, 25));
		Password.setBounds(53, 226, 137, 19);
		contentPane.add(Password);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		
			}
		});
		btnCancel.setFont(new Font("Modern No. 20", Font.BOLD, 25));
		btnCancel.setBounds(340, 344, 109, 32);
		contentPane.add(btnCancel);
		
		passwordField = new JPasswordField();
		passwordField.setFont(new Font("Modern No. 20", Font.BOLD, 15));
		passwordField.setBounds(284, 221, 200, 32);
		contentPane.add(passwordField);
		
		JLabel lblNewLabel_1 = new JLabel(" ");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\Dell\\Desktop\\photos\\loginimg.jpg"));
		lblNewLabel_1.setBounds(10, 11, 499, 417);
		contentPane.add(lblNewLabel_1);
	}
}
