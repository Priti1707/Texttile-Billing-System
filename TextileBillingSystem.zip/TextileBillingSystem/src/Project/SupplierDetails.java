package Project;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

//import SupplierDetailsRp.jrxml;

import java.awt.Color;

@SuppressWarnings("serial")
public class SupplierDetails extends JFrame {

	private JPanel contentPane;
	private JTextField txtSuppID;
	private JTextField txtContNo;
	private JTextField txtAddress;
	private JTextField txtSuppName;
	private JTextField txtEmail;
	private JTextField txtSearch;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public void clear()
	{
		
		txtContNo.setText("");
		txtAddress.setText("");
		txtEmail.setText("");
		txtSearch.setText("");
		txtSuppName.setText("");
	}
	public void tableDetails()
	{
		DefaultTableModel dtm=(DefaultTableModel)table.getModel();
		
		table.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
		dtm.setRowCount(0);
		try
		{
			Connection con=ConnectionProvider.getcon();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from suppdetails");
			while(rs.next())
			{
				dtm.addRow(new Object[] {rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5)});
			}
			
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null, e);
		}
		
	}
	private void autoID()
	{
		try
		{
			Connection con=ConnectionProvider.getcon();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select Max(SuppID) from suppdetails ");
			rs.next();
			rs.getString("Max(SuppID)");
			if(rs.getString("Max(SuppID)")==null)
			{
				txtSuppID.setText("01");
			}
			else
			{
				Long id = Long.parseLong(rs.getString("Max(SuppID)").substring(0,rs.getString("Max(SuppID)").length()));
				id++;
				txtSuppID.setText("0" + String.format("%d",id));	
			}
		
		}
		catch(Exception e)
		{
			
			JOptionPane.showMessageDialog(null, e);
		}
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SupplierDetails frame = new SupplierDetails();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SupplierDetails() {
		setTitle("Supplier Details");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 807, 497);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 165, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(9, 47, 770, 146);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Supplier ID :");
		
		lblNewLabel.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel.setBounds(10, 26, 95, 25);
		panel.add(lblNewLabel);
		
		JLabel lblContactNo = new JLabel("Contact No :");
		lblContactNo.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblContactNo.setBounds(6, 72, 80, 25);
		panel.add(lblContactNo);
		
		JLabel lblAddress = new JLabel("Address :");
		lblAddress.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblAddress.setBounds(30, 109, 73, 25);
		panel.add(lblAddress);
		
		JLabel lblSupplierName = new JLabel("Supplier Name :");
		lblSupplierName.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblSupplierName.setBounds(354, 33, 114, 25);
		panel.add(lblSupplierName);
		
		JLabel lblEmail = new JLabel("Email :");
		lblEmail.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblEmail.setBounds(402, 71, 66, 25);
		panel.add(lblEmail);
		
		JLabel lblSearchBy = new JLabel("Search By :");
		lblSearchBy.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblSearchBy.setBounds(375, 109, 80, 25);
		panel.add(lblSearchBy);
		
		txtSuppID = new JTextField();
		txtSuppID.setBounds(102, 29, 226, 28);
		panel.add(txtSuppID);
		txtSuppID.setColumns(10);
		
		txtContNo = new JTextField();
		txtContNo.setColumns(10);
		txtContNo.setBounds(103, 71, 225, 25);
		panel.add(txtContNo);
		
		txtAddress = new JTextField();
		txtAddress.setColumns(10);
		txtAddress.setBounds(102, 111, 226, 26);
		panel.add(txtAddress);
		
		txtSuppName = new JTextField();
		txtSuppName.setColumns(10);
		txtSuppName.setBounds(466, 31, 197, 27);
		panel.add(txtSuppName);
		
		txtEmail = new JTextField();
		txtEmail.setColumns(10);
		txtEmail.setBounds(468, 69, 197, 28);
		panel.add(txtEmail);
		
		txtSearch = new JTextField();
		txtSearch.setColumns(10);
		txtSearch.setBounds(467, 109, 197, 28);
		panel.add(txtSearch);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = txtSearch.getText();
				try {
					Connection con= ConnectionProvider.getcon();
					java.sql.Statement st= con.createStatement();
					ResultSet rs = ((java.sql.Statement) st).executeQuery("select * from suppdetails where SuppID='"+id+"'");
					if(rs.next())
					{
						txtSuppID.setEditable(false);
						txtSuppID.setText(rs.getString(1));
						txtSuppName.setText(rs.getString(2));
						txtContNo.setText(rs.getString(3));
						txtEmail.setText(rs.getString(4));
						txtAddress.setText(rs.getString(5));
							
					}
					else 
					{
						JOptionPane.showMessageDialog(null, "Supplier does not Exist");
						clear();
						tableDetails();
						autoID();
					}
					
				}
				catch(Exception e1) {
					JOptionPane.showMessageDialog(null, e1);
				} 
			}
	
			
		});
		btnSearch.setFont(new Font("Modern No. 20", Font.PLAIN, 18));
		btnSearch.setBounds(678, 109, 89, 32);
		panel.add(btnSearch);
		
		JLabel lblNewLabel_1 = new JLabel("   Supplier Details");
		lblNewLabel_1.setFont(new Font("Modern No. 20", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(307, 12, 150, 22);
		contentPane.add(lblNewLabel_1);
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id =  txtSuppID.getText();
				String name= txtSuppName.getText();
				 String Cont= txtContNo.getText();
				String email= txtEmail.getText();
			    String add= txtAddress.getText();
				 

				try
				{
					Connection con=ConnectionProvider.getcon();	
					PreparedStatement ps = con.prepareStatement("insert into suppdetails values(?,?,?,?,?)");
					ps.setString(1,id);
					ps.setString(2,name);
					ps.setString(3,Cont);
					ps.setString(4,email);
					ps.setString(5,add);
					 
					ps.executeUpdate();
					JOptionPane.showMessageDialog(null,"Record SuccessFully Added...");
					tableDetails();
					clear(); 
					autoID();
					
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null, e1);
				}
			}	
		});
			
	
		btnSave.setFont(new Font("Modern No. 20", Font.PLAIN, 19));
		btnSave.setBounds(688, 215, 89, 31);
		contentPane.add(btnSave);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id =  txtSuppID.getText();
				String name= txtSuppName.getText();
				String Cont= txtContNo.getText();
				String email= txtEmail.getText();
		 	    String add=txtAddress.getText();
				 
				 
				try
				{
					Connection con=ConnectionProvider.getcon();
					PreparedStatement ps = con.prepareStatement("update suppdetails set SuppID=?,SuppName=?,ContNo=?,Email=?,Address=? where SuppID='"+id+"'");
					ps.setString(1,id);
					ps.setString(2,name);
					ps.setString(3,Cont);
					ps.setString(4,email);
					ps.setString(5,add);
					
					ps.executeUpdate();
					JOptionPane.showMessageDialog(null,"Record Successfully Updated...");
					tableDetails();
					clear(); 
					autoID();
					
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null,e1);
				}
			}	
		});
			
		btnUpdate.setFont(new Font("Modern No. 20", Font.PLAIN, 19));
		btnUpdate.setBounds(687, 258, 89, 29);
		contentPane.add(btnUpdate);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String id=txtSuppID.getText();
				try
				{
					Connection con=ConnectionProvider.getcon();
					Statement st=con.createStatement();
					st.executeUpdate("DELETE FROM suppdetails WHERE SuppID='"+id+"'");
					JOptionPane.showMessageDialog(null,"Record Successfully Deleted...");
					tableDetails();
					clear();
					autoID();
				}
				catch(Exception e1)
				{
				
				}
			}
		});
			
		btnDelete.setFont(new Font("Modern No. 20", Font.PLAIN, 19));
		btnDelete.setBounds(688, 300, 89, 31);
		contentPane.add(btnDelete);
		
		JButton btnPrint = new JButton("Print");
		btnPrint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					 Class.forName("com.mysql.cj.jdbc.Driver");
					 Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/textilebilling","root","root");
					 String sql= "select * from suppdetails";
					 
					 JasperDesign jdesign= JRXmlLoader.load("C:\\Users\\Dell\\eclipse-workspace\\TextileBillingSystem\\src\\Project\\SupplierDetailsRp.jrxml");
					 JRDesignQuery updateQuery = new JRDesignQuery();
					 
					 updateQuery.setText(sql);
					 jdesign.setQuery(updateQuery);
					 
					 JasperReport jreport = JasperCompileManager.compileReport(jdesign);
					 JasperPrint JasperPrint =JasperFillManager.fillReport(jreport,null,con);
					 JasperViewer.viewReport(JasperPrint,false);
					 
					
				}
			catch(Exception e1) {
				JOptionPane.showMessageDialog(null,e1);
			}

				
				
				
			}
		});
		
		btnPrint.setFont(new Font("Modern No. 20", Font.PLAIN, 19));
		btnPrint.setBounds(688, 342, 89, 32);
		contentPane.add(btnPrint);
		
		JButton btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clear();
				autoID();
			}
		});
		btnClear.setFont(new Font("Modern No. 20", Font.PLAIN, 19));
		btnClear.setBounds(688, 382, 89, 30);
		contentPane.add(btnClear);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnExit.setFont(new Font("Modern No. 20", Font.PLAIN, 19));
		btnExit.setBounds(688, 423, 89, 30);
		contentPane.add(btnExit);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 213, 660, 234);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
			},
			new String[] {
				"SuppID", "SuppName", "ContNo", "Email", "Address"
			}
		));
		scrollPane.setViewportView(table);
		tableDetails();
		autoID();
	}
}
