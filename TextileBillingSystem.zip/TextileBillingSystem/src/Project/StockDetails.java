package Project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;



public class StockDetails extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtMatID;
	private JTextField txtQuantity;
	private JTextField txtRate;
	private JTable table;
	private JTextField txtMatName;
	private JTextField txtSearch;

	/**
	 * Launch the application.
	 */
	public void clear()
	{
		txtMatID.setText("");
		txtMatName.setText("");
		txtQuantity.setText("");
		txtRate.setText("");
		txtSearch.setText("");
	}
	public void tableDetails()
	{
		DefaultTableModel dtm=(DefaultTableModel)table.getModel();
		
		table.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
		dtm.setRowCount(0);
		try
		{
			Connection con=ConnectionProvider.getcon();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from stockdetails");
			while(rs.next())
			{
				dtm.addRow(new Object[] {rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)});
			}
			
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null, e);
		}
		
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StockDetails frame = new StockDetails();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StockDetails() {
		setTitle("Stock Details");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 764, 485);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 165, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id =  txtMatID.getText();
				String Mname= txtMatName.getText();
				 String Quant= txtQuantity.getText();
			    String Rate= txtRate.getText();
				 

				try
				{
					Connection con=ConnectionProvider.getcon();	
					PreparedStatement ps = con.prepareStatement("insert into stockdetails values(?,?,?,?)");
					ps.setString(1,id);
					ps.setString(2,Mname);
					ps.setString(3,Quant);
					ps.setString(4,Rate);
					 
					ps.executeUpdate();
					JOptionPane.showMessageDialog(null," Record SuccessFully Added....");
					tableDetails();
					clear(); 
					
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null, e1);
				}
				
		
			
			}
		});
		btnSave.setBounds(633, 210, 89, 31);
		btnSave.setFont(new Font("Modern No. 20", Font.PLAIN, 18));
		contentPane.add(btnSave);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id =  txtMatID.getText();
				String Mname= txtMatName.getText();
				 String Quant= txtQuantity.getText();
			    String Rate= txtRate.getText();
				 

				try
				{
					Connection con=ConnectionProvider.getcon();	
					PreparedStatement ps = con.prepareStatement("update stockdetails set MaterialID=?,MaterialName=?,Quantity=?,Rate=? where MaterialID='"+id+"'");
					ps.setString(1,id);
					ps.setString(2,Mname);
					ps.setString(3,Quant);
					ps.setString(4,Rate);
					 
					ps.executeUpdate();
					JOptionPane.showMessageDialog(null,"Record Successfully Updated...");
					tableDetails();
					clear(); 
					
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null, e1);
				}
				
		
			}
		});
		btnUpdate.setBounds(635, 251, 89, 30);
		btnUpdate.setFont(new Font("Modern No. 20", Font.PLAIN, 18));
		contentPane.add(btnUpdate);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id=txtMatID.getText();
				try
				{
					Connection con=ConnectionProvider.getcon();
					Statement st=con.createStatement();
					st.executeUpdate("DELETE FROM stockdetails WHERE MaterialID='"+id+"'");
					JOptionPane.showMessageDialog(null," Record Successfully Deleted...");
					tableDetails();
					clear();
				}
				catch(Exception e1)
				{
				
				}
			}
			
		});
		btnDelete.setBounds(634, 291, 89, 30);
		btnDelete.setFont(new Font("Modern No. 20", Font.PLAIN, 18));
		contentPane.add(btnDelete);
		
		JButton btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clear();
			}
		});
		btnClear.setBounds(634, 372, 89, 28);
		btnClear.setFont(new Font("Modern No. 20", Font.PLAIN, 18));
		contentPane.add(btnClear);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnExit.setBounds(634, 406, 89, 29);
		btnExit.setFont(new Font("Modern No. 20", Font.PLAIN, 18));
		contentPane.add(btnExit);
		
		JPanel panel = new JPanel();
		panel.setBounds(22, 47, 721, 135);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Material ID :");
		lblNewLabel.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel.setBounds(49, 26, 89, 23);
		panel.add(lblNewLabel);
		
		JLabel lblAvailableQuantity = new JLabel("Available Quantity :");
		lblAvailableQuantity.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblAvailableQuantity.setBounds(10, 71, 133, 23);
		panel.add(lblAvailableQuantity);
		
		JLabel lblMaterialName = new JLabel("Material Name :");
		lblMaterialName.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblMaterialName.setBounds(347, 31, 103, 23);
		panel.add(lblMaterialName);
		
		JLabel lblRatePerMaterial = new JLabel("Rate Per Material :");
		lblRatePerMaterial.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblRatePerMaterial.setBounds(330, 69, 124, 23);
		panel.add(lblRatePerMaterial);
		
		txtMatID = new JTextField();
		txtMatID.setBounds(142, 27, 174, 26);
		panel.add(txtMatID);
		txtMatID.setColumns(10);
		
		txtQuantity = new JTextField();
		txtQuantity.setColumns(10);
		txtQuantity.setBounds(142, 72, 174, 27);
		panel.add(txtQuantity);
		
		txtRate = new JTextField();
		txtRate.setColumns(10);
		txtRate.setBounds(461, 63, 171, 27);
		panel.add(txtRate);
		
		txtMatName = new JTextField();
		txtMatName.setColumns(10);
		txtMatName.setBounds(461, 25, 171, 28);
		panel.add(txtMatName);
		
		JLabel lblSearch = new JLabel("Search :");
		lblSearch.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblSearch.setBounds(403, 103, 71, 23);
		panel.add(lblSearch);
		
		txtSearch = new JTextField();
		txtSearch.setFont(new Font("Modern No. 20", Font.PLAIN, 16));
		txtSearch.setColumns(10);
		txtSearch.setBounds(462, 97, 123, 26);
		panel.add(txtSearch);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = txtSearch.getText();
				try {
					Connection con= ConnectionProvider.getcon();
					java.sql.Statement st= con.createStatement();
					ResultSet rs = ((java.sql.Statement) st).executeQuery("select * from stockdetails where MatID='"+id+"'");
					if(rs.next())
					{
						txtMatID.setEditable(false);
						txtMatID.setText(rs.getString(1));
						txtMatName.setText(rs.getString(2));
						txtQuantity.setText(rs.getString(3));
						txtRate.setText(rs.getString(4));
						
							
					}
					else 
					{
						JOptionPane.showMessageDialog(null, "Stock does not Exist");
						clear();
						tableDetails();
			
					}
					
				}
				catch(Exception e1) {
					JOptionPane.showMessageDialog(null, e1);
				} 
			}
		});
		btnSearch.setFont(new Font("Modern No. 20", Font.PLAIN, 18));
		btnSearch.setBounds(604, 98, 89, 29);
		panel.add(btnSearch);
		
		JLabel lblNewLabel_1 = new JLabel("   Stock Details");
		lblNewLabel_1.setBounds(312, 11, 115, 25);
		lblNewLabel_1.setFont(new Font("Modern No. 20", Font.PLAIN, 18));
		contentPane.add(lblNewLabel_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(22, 219, 578, 216);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
			},
			new String[] {
				"MateriaID", "MaterialName", "Quantity", "Rate"
			}
		));
		scrollPane.setViewportView(table);
		
		JButton btnPrint = new JButton("Print");
		btnPrint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					 Class.forName("com.mysql.cj.jdbc.Driver");
					 Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/textilebilling","root","root");
					 String sql= "select * from stockdetails";
					 
					 JasperDesign jdesign= JRXmlLoader.load("C:\\Users\\Dell\\eclipse-workspace\\TextileBillingSystem\\src\\Project\\StockRp.jrxml");
					 JRDesignQuery updateQuery = new JRDesignQuery();
					 
					 updateQuery.setText(sql);
					 jdesign.setQuery(updateQuery);
					 
					 JasperReport jreport = JasperCompileManager.compileReport(jdesign);
					 JasperPrint JasperPrint =JasperFillManager.fillReport(jreport,null,con);
					 JasperViewer.viewReport(JasperPrint,false);
					 
					
				}
			catch(Exception e1) {
				JOptionPane.showMessageDialog(null,e1);
			}
			}
		});
		btnPrint.setFont(new Font("Modern No. 20", Font.PLAIN, 18));
		btnPrint.setBounds(634, 332, 89, 29);
		contentPane.add(btnPrint);
		tableDetails();
	}
}


