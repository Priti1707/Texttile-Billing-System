
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.Color;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import com.toedter.calendar.JDateChooser;

import Project.ConnectionProvider;

public class CustomerOrder extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtOrderID;
	private JTextField txtMatID;
	private JTextField txtQuantity;
	@SuppressWarnings("rawtypes")
	private JComboBox comboCustID;
	@SuppressWarnings("rawtypes")
	private JComboBox comboMatName;
	@SuppressWarnings("rawtypes")
	private JComboBox comboSize;
	@SuppressWarnings("rawtypes")
	private JComboBox comboCustName;
	

	/**
	 * Launch the application.
	 */
	public void clear()
	{
		txtOrderID.setText("");
		comboCustID.removeItemAt(0);
		comboCustName.removeItemAt(0);
		txtMatID.setText("");
		comboMatName.removeItemAt(0);
		comboSize.removeItemAt(0);
		txtQuantity.setText("");
		
	}
	private void autoID()
	{
		try
		{
			Connection con=ConnectionProvider.getcon();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select Max(OrderID) from customerorder ");
			rs.next();
			rs.getString("Max(OrderID)");
			if(rs.getString("Max(OrderID)")==null)
			{
				txtOrderID.setText("01");
			}
			else
			{
				Long id = Long.parseLong(rs.getString("Max(OrderID)").substring(0,rs.getString("Max(OrderID)").length()));
				id++;
				txtOrderID.setText("0" + String.format("%d",id));	
			}
		
		}
		catch(Exception e)
		{
			
			JOptionPane.showMessageDialog(null, e);
		}
		
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CustomerOrder frame = new CustomerOrder();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public CustomerOrder() {
		setTitle("Customer Order");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 774, 502);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 165, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 11, 738, 165);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Customer Details ");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Modern No. 20", Font.PLAIN, 16));
		lblNewLabel.setBounds(10, 11, 136, 17);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Order ID :- ");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(10, 41, 97, 17);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Customer ID :-");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1_1.setBounds(10, 97, 97, 17);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Date :-");
		lblNewLabel_1_2.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1_2.setBounds(430, 41, 61, 17);
		panel.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Customer Name :-");
		lblNewLabel_1_3.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1_3.setBounds(366, 98, 125, 17);
		panel.add(lblNewLabel_1_3);
		
		txtOrderID = new JTextField();
		txtOrderID.setBounds(85, 39, 171, 20);
		panel.add(txtOrderID);
		txtOrderID.setColumns(10);
		
		JComboBox comboCustID = new JComboBox();
		comboCustID.setBounds(98, 94, 171, 22);
		panel.add(comboCustID);
		try
		{
			try
			{
				int i = 0;
				Connection con = ConnectionProvider.getcon();
				Statement st = con.createStatement();
				
				ResultSet rs=st.executeQuery("select * from cust_details ");
					
				
				while(rs.next())
				{		
					i = 1 ;
					comboCustID.addItem(rs.getString("CustID")); 
				}
				con.close();
				if(i==0)
				{
					 
					JOptionPane.showMessageDialog(null,"Customer ID Not Available");
					
				}
			}
			catch(Exception e)
			{
				JOptionPane.showMessageDialog(null, e);
			}
		
		
		JComboBox comboCustName = new JComboBox();
		comboCustName.setFont(new Font("Modern No. 20", Font.PLAIN, 16));
		comboCustName.setEditable(true);
		comboCustName.setBounds(501, 94, 171, 22);
		panel.add(comboCustName);
		
		
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setBounds(501, 38, 171, 20);
		panel.add(dateChooser);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(10, 187, 636, 231);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblMaterialDetails = new JLabel("Material Details ");
		lblMaterialDetails.setFont(new Font("Modern No. 20", Font.PLAIN, 16));
		lblMaterialDetails.setBounds(10, 11, 136, 17);
		panel_1.add(lblMaterialDetails);
		
		JLabel lblNewLabel_1_4 = new JLabel("Material Name :-");
		lblNewLabel_1_4.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1_4.setBounds(10, 53, 119, 17);
		panel_1.add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_5 = new JLabel("Material ID :-");
		lblNewLabel_1_5.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1_5.setBounds(32, 115, 97, 17);
		panel_1.add(lblNewLabel_1_5);
		
		JLabel lblNewLabel_1_6 = new JLabel("Size :");
		lblNewLabel_1_6.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1_6.setBounds(361, 53, 73, 17);
		panel_1.add(lblNewLabel_1_6);
		
		JLabel lblNewLabel_1_7 = new JLabel("Extra Quantity :-");
		lblNewLabel_1_7.setFont(new Font("Modern No. 20", Font.PLAIN, 15));
		lblNewLabel_1_7.setBounds(315, 115, 119, 17);
		panel_1.add(lblNewLabel_1_7);
		
		txtMatID = new JTextField();
		txtMatID.setColumns(10);
		txtMatID.setBounds(145, 113, 171, 20);
		panel_1.add(txtMatID);
		
		txtQuantity = new JTextField();
		txtQuantity.setColumns(10);
		txtQuantity.setBounds(455, 113, 171, 20);
		panel_1.add(txtQuantity);
		
		JComboBox comboMatName = new JComboBox();
		comboMatName.setModel(new DefaultComboBoxModel(new String[] {"T-Shirt ", "Jeans", "Curta", "Blankets", "Towels", "Sweaters", "Suits", "Coats"}));
		comboMatName.setEditable(true);
		comboMatName.setFont(new Font("Modern No. 20", Font.PLAIN, 16));
		comboMatName.setBounds(145, 50, 171, 22);
		panel_1.add(comboMatName);
		
		JComboBox comboSize = new JComboBox();
		comboSize.setModel(new DefaultComboBoxModel(new String[] {"30", "32", "34", "36", "38", "40"}));
		comboSize.setEditable(true);
		comboSize.setFont(new Font("Modern No. 20", Font.PLAIN, 16));
		comboSize.setBounds(455, 50, 171, 22);
		panel_1.add(comboSize);
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			String Oid =  txtOrderID.getText();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			JDateChooser txtdateChooser=null;
			@SuppressWarnings("null")
			String date= sdf.format(txtdateChooser.getDate());
			String Cid= comboCustID.getSelectedItem().toString();
			String Cname= comboCustName.getSelectedItem().toString();
		    String Mid= txtMatID.getText();
		    String Mname= comboMatName.getSelectedItem().toString();
		    String size=comboSize.getSelectedItem().toString();
		    String Quant= txtQuantity.getText();

			try
			{
				Connection con=ConnectionProvider.getcon();	
				PreparedStatement ps = con.prepareStatement("insert into customerorder values(?,?,?,?,?,?,?,?)");
				ps.setString(1,Oid);
				ps.setString(2,date);
				ps.setString(3,Cid);
				ps.setString(4,Cname);
				ps.setString(5,Mid);
				ps.setString(6,Mname);
				ps.setString(7,size);
				ps.setString(8,Quant);
		 
				ps.executeUpdate();
				JOptionPane.showMessageDialog(null,"Customer Order SuccessFully Added...");
			
				clear(); 
				autoID();
				
			}
			catch(Exception e1)
			{
				
			}
		}
		});
		btnSave.setFont(new Font("Modern No. 20", Font.PLAIN, 17));
		btnSave.setBounds(20, 429, 89, 23);
		contentPane.add(btnSave);
		
		JButton btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clear();
				autoID();
			}
			
		});
		btnClear.setFont(new Font("Modern No. 20", Font.PLAIN, 17));
		btnClear.setBounds(343, 429, 89, 23);
		contentPane.add(btnClear);
		
		JButton btnPrint = new JButton("Print");
		btnPrint.setFont(new Font("Modern No. 20", Font.PLAIN, 17));
		btnPrint.setBounds(458, 429, 89, 23);
		contentPane.add(btnPrint);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnExit.setFont(new Font("Modern No. 20", Font.PLAIN, 17));
		btnExit.setBounds(557, 429, 89, 23);
		contentPane.add(btnExit);
		autoID();
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Oid=txtOrderID.getText();
				try
				{
					Connection con=ConnectionProvider.getcon();
					Statement st=con.createStatement();
					st.executeUpdate("DELETE FROM customerorder WHERE OrderID='"+Oid+"'");
					JOptionPane.showMessageDialog(null,"Order Successfully Deleted...");
					clear();
					autoID();
				}
				catch(Exception e1)
				{
				
				}
			}
		});
		btnDelete.setFont(new Font("Modern No. 20", Font.PLAIN, 17));
		btnDelete.setBounds(228, 429, 89, 23);
		contentPane.add(btnDelete);
		
		JButton btnUpdate = new JButton("Update ");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Oid =  txtOrderID.getText();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				String date= sdf.format(dateChooser.getDate());
				String Cid= comboCustID.getSelectedItem().toString();
				String Cname= comboCustName.getSelectedItem().toString();
			    String Mid= txtMatID.getText();
			    String Mname= comboMatName.getSelectedItem().toString();
			    String size=comboSize.getSelectedItem().toString();
			    String Quant= txtQuantity.getText();

				try
				{
					Connection con=ConnectionProvider.getcon();	
					PreparedStatement ps = con.prepareStatement("update customerorder set OrderID=?,Date=?,CustID=?,CustName=?,MatID=?,MatName=?,Size=?,Quantity=? where OrderID='"+Oid+"'");
					ps.setString(1,Oid);
					ps.setString(2,date);
					ps.setString(3,Cid);
					ps.setString(4,Cname);
					ps.setString(5,Mid);
					ps.setString(6,Mname);
					ps.setString(7,size);
					ps.setString(8,Quant);
			 
					ps.executeUpdate();
					JOptionPane.showMessageDialog(null,"Customer Order SuccessFully Updated...");
				
					clear(); 
					autoID();
					
				}
				catch(Exception e1)
				{
					
				}
			}
		});
		btnUpdate.setFont(new Font("Modern No. 20", Font.PLAIN, 17));
		btnUpdate.setBounds(119, 429, 89, 23);
		contentPane.add(btnUpdate);
		}
		finally
		{
		}
	}
	}